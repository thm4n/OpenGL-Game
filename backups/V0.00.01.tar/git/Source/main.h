#ifndef _MAIN_H_
#define _MAIN_H_

#include "Dependencies/Includes.h"
#include "Dependencies/Definitions.h"

#endif