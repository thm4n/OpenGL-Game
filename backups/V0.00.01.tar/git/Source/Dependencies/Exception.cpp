#include "Exception.h"

Exception::Exception(maj_t maj, const char* description) {
	this->_maj = maj;
	this->_description = description;
}

const char* Exception::maj_tToString() const {
	switch((int)(this->_maj)) {
	case maj_t::graphics_error:
		return "Graphics Error";
	}
	return "Undefined Error";
}

const char* Exception::what() const throw() {
	std::cout << maj_tToString() << ": " << this->_description;
	return "";
}
