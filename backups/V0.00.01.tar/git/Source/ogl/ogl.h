#ifndef _OGL_H_
#define _OGL_H_

#include "../main.h"

namespace ogl {
	void oglInit();
	void oglTerminate();
	void gladInit();
}

#endif