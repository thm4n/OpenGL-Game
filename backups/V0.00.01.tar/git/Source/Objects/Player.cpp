#include "Player.h"

namespace game {
	Player::Player() : Object() {
		this->_type = obj_t::_player;
		this->_shader = nullptr;
		this->_camera = nullptr;
	}

	Player::~Player() {
		printf("PLAYER DESTRUCTOR BEGIN: \n");
		printf("PLAYER DESTRUCTOR END: SUCCESS\n");
	}

	void Player::update() {
		this->_vel += this->_acc;
		this->_pos += this->_vel;
		this->_camera->_position = this->_pos;
	}
	
	void Player::render(glm::mat4 view, glm::mat4 projection) {
UNUSED(view);
UNUSED(projection);
	}

	void Player::inputUpdate(int key, int action) {
		float toggle = action == GLFW_PRESS ? 1.00f : 0.00f;
		
		switch(key) {
		case GLFW_KEY_W:
			this->_vel =  this->_camera->_front * (PLAYER_BASE_SPEED * toggle);
			break;
		case GLFW_KEY_S:
			this->_vel = -this->_camera->_front * (PLAYER_BASE_SPEED * toggle);
			break;
		case GLFW_KEY_D:
			this->_vel =  this->_camera->_right * (PLAYER_BASE_SPEED * toggle);
			break;
		case GLFW_KEY_A:
			this->_vel = -this->_camera->_right * (PLAYER_BASE_SPEED * toggle);
			break;
		}
	}
	
	void Player::setCamera(Camera* camera) {
		this->_camera = camera;
	}
}
