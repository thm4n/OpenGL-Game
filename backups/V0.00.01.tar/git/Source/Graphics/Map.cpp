#include "Map.h"

namespace game {
	Map::Map() {

	}

	Map::~Map() {

	}

	void Map::update() {

	}

	void Map::render() {
		
	}
}
