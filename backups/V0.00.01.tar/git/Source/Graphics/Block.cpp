#include "Block.h"

namespace game {
	Block::Block(int x, int y, int z, block_t type) {
		this->_pos = glm::vec3(x, y, z);
		this->_type = type;

		float vertices[] = {
			0.0f, 0.0f, 1.0f,
			1.0f, 0.0f, 1.0f,
			0.0f, 1.0f, 1.0f,
			1.0f, 1.0f, 1.0f,
			0.0f, 0.0f, 0.0f,
			1.0f, 0.0f, 0.0f,
			0.0f, 1.0f, 0.0f,
			1.0f, 1.0f, 0.0f
		};

		unsigned int indices[] = {
			2, 6, 7, 2, 3, 7, //top
			0, 4, 5, 0, 1, 5, //bottom
			0, 2, 6, 0, 4, 6, //left
			1, 3, 7, 1, 5, 7, //right
			0, 2, 3, 0, 1, 3, //front
			4, 6, 7, 4, 5, 7  //back
		};

		glGenVertexArrays(1, &this->_vao);
		glGenBuffers(1, &this->_vbo);
		glGenBuffers(1, &this->_ebo);

		glBindVertexArray(this->_vao);

		glBindBuffer(GL_ARRAY_BUFFER, this->_vbo);
		glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, this->_ebo);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(0);

		this->loadShader();
	}
	
	Block::~Block() {
		delete this->_shader;
		
		glDeleteVertexArrays(1, &this->_vao);
		glDeleteBuffers(1, &this->_vbo);
		glDeleteBuffers(1, &this->_ebo);
	}


	void Block::loadShader() {
		this->_shader = new Shader("Block.vs", "Block.fs");
	}

	void Block::update() {
		
	}
		
	void Block::render(glm::mat4 view, glm::mat4 projection) {
		this->_shader->use();

		glm::mat4 model = glm::mat4(1.0f);
		model = glm::translate(model, this->_pos);
		this->_shader->setMat4("model", model);
		this->_shader->setMat4("projection", projection);
		this->_shader->setMat4("view", view);
		
		glBindVertexArray(this->_vao);
		glDrawElements( GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
	}
}
