#ifndef _EXCEPTION_H_
#define _EXCEPTION_H_

#include "../main.h"

class Exception : public std::exception {
public:
	enum maj_t : int {
		undefined = 0,
		graphics_error = 1,

	};

	Exception(maj_t maj = Exception::undefined, const char* description = "");

	const char* maj_tToString() const;

	virtual const char* what() const throw();

private:
	maj_t _maj;
	std::string _description;
};

#endif