#version 330 core

out vec4 FragColor;

void main() {
	FragColor = vec4(0.5, 0.66, 0.12);
}